import "./functions/bootstrap.js";
import "./functions/save.js";
import "./functions/tick.js";
import "./functions/health.js";
import "./functions/backupWeekly.js";
import "./functions/chat.js";
